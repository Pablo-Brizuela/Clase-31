function saludar(mensaje) {
  return new Promise((resolve, reject) => {
    /**
     * logica
     */
    setTimeout(() => {
      if (mensaje) {
        resolve(mensaje);
      }
      reject("Upsssss");
    }, 500);
  });
}

// saludar("Hola, ")
//   .then((respuesta) => {
//     return saludar(respuesta + "esto ");
//   })
//   .then((respuesta) => {
//     return saludar(respuesta + "es ");
//   })
//   .then((respuesta) => {
//     return saludar(); //respuesta + "un "
//   })
//   .then((respuesta) => {
//     return saludar(respuesta + "mensaje");
//   })
//   .then((respuesta) => {
//     console.log(respuesta);
//   })
//   .catch((error) => {
//     console.log(error);
//   });

// Promise.all([
//   saludar("actores"),
//   saludar("generos"),
//   saludar("productoras"),
//   saludar("cines"),
// ])
//   .then(([actores, generos, productoras, cines]) => {
//     console.log({ actores });
//     console.log({ generos });
//     console.log({ productoras });
//     console.log({ cines });
//   })
//   .catch((error) => {
//     console.log({ error });
//   });

// Promise.allSettled([
//   saludar("actores"),
//   saludar("generos"),
//   saludar(),
//   saludar("cines"),
// ]).then((respuesta) => {
//   // console.log({ respuesta });
//   const fulfilled = respuesta.filter((res) => res.status == "fulfilled");
//   const rejected = respuesta.filter((res) => res.status == "rejected");
//   console.log({ fulfilled });
//   console.log({ rejected });
// });

async function init() {
  try {
    let mensaje = await saludar("Hola, ");
    mensaje = mensaje + (await saludar("esto "));
    mensaje += await saludar(); //"es "
    mensaje += await saludar("un ");
    mensaje += await saludar("mensaje ");
    console.log(mensaje);
  } catch (error) {
    console.log({ error });
  }
}

// init();

async function init1() {
  try {
    const [actores, generos, productoras, cines] = await Promise.all([
      saludar("actores"),
      saludar(),
      saludar("productoras"),
      saludar("cines"),
    ]);

    console.log({ actores });
    console.log({ generos });
    console.log({ productoras });
    console.log({ cines });
  } catch (error) {
    console.log({ error });
  }
}

init1();
